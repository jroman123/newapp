package com.example.julio.bookloot2;


import java.util.ArrayList;

import android.support.v4.content.ContextCompat;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class NewsAdapter extends ArrayAdapter<NewsFeed> {

	ArrayList<NewsFeed> NewsList;
	LayoutInflater vi;
	int Resource;
	ViewHolder holder;

	public NewsAdapter(Context context, int resource, ArrayList<NewsFeed> objects) {
		super(context, resource, objects);
		vi = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		Resource = resource;
		NewsList = objects;

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// convert view = design
		View v = convertView;
		if (v == null) {
			holder = new ViewHolder();
			v = vi.inflate(Resource, null);
			holder.tvIndex = (TextView) v.findViewById(R.id.tvIndex);
			holder.tvName = (TextView) v.findViewById(R.id.tvName);
			holder.tvId = (TextView) v.findViewById(R.id.tvId);
			holder.tvAuthor = (TextView) v.findViewById(R.id.tvAuthor);
			v.setTag(holder);
		} else {
			holder = (ViewHolder) v.getTag();
		}
		holder.tvIndex.setText(NewsList.get(position).getIndex());
		holder.tvName.setText(NewsList.get(position).getName());
		holder.tvId.setText(NewsList.get(position).getId());
		holder.tvAuthor.setText(NewsList.get(position).getAuthor());

		NewsFeed currentImage = getItem(position);
		if (v == null) {
			v = LayoutInflater.from(getContext()).inflate(
					R.layout.row, parent, false);
		}


// Find the ImageView in the xml layout with the ID image.
		ImageView imageView = (ImageView) v.findViewById(R.id.number);
		// Check if an image is provided for this word or not
		if (currentImage.hasImage()) {
			// If an image is available, display the provided image based on the resource ID
			imageView.setImageResource(currentImage.getImageResourceId());
			// Make sure the view is visible
			imageView.setVisibility(View.VISIBLE);
		} else {
			// Otherwise hide the ImageView (set visibility to GONE)
			imageView.setVisibility(View.GONE);
		}
		return v;

	}

	static class ViewHolder {
		public TextView tvIndex;
	    public TextView tvName;
		public TextView tvId;
		public TextView tvAuthor;
		}


	}