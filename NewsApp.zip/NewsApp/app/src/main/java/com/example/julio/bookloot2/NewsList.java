package com.example.julio.bookloot2;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.ParseException;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

public class NewsList extends Activity {
    public static int viewNews;
    public static int errorCode;
    public static int content;
    public static String urlId;
    public static String URL2;

    ArrayList<NewsFeed> NewsFeedList;

    NewsAdapter adapter;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news_list);



        NewsFeedList = new ArrayList<NewsFeed>();
        NewsList.URL2 = (String) getString(R.string.url);

        //Replace Spaces
        URL2 = URL2.replaceAll(" ", "%20");
        System.out.println(URL2);
        new JSONAsyncTask().execute(URL2);

        ListView listview = (ListView) findViewById(R.id.list);
        adapter = new NewsAdapter(getApplicationContext(), R.layout.row, NewsFeedList);
        //TextView set = (TextView) findViewById(R.id.tvName);
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position,
                                    long id) {
                Toast.makeText(getApplicationContext(), getString(R.string.mss1), Toast.LENGTH_LONG).show();
                TextView Link = (TextView) findViewById(R.id.tvId);
                NewsList.urlId = Link.getText().toString();
                String url = NewsList.urlId;
                redirect(url);

            }
        });
                 }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                getString(R.string.subject1), // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse(getString(R.string.urlPath)),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse(getString(R.string.pack1))
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                getString(R.string.subject1), // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse(getString(R.string.urlPath)),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse(getString(R.string.pack1))
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }

    public void redirect(String link) {
        Toast.makeText(getApplicationContext(), getString(R.string.mss1), Toast.LENGTH_LONG).show();

        Intent x = new Intent(Intent.ACTION_VIEW);
        x.setData(Uri.parse(link));
        startActivity(x);

    }

    public void home(View view) {
        Intent i = new Intent(this, NewsMain.class);
        startActivity(i);
        finish();
    }

    class JSONAsyncTask extends AsyncTask<String, Void, Boolean> {

        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(NewsList.this);
            dialog.setMessage(getString(R.string.mss2));
            dialog.setTitle(getString(R.string.mss3));
            dialog.show();
            dialog.setCancelable(false);

        }

        @Override
        protected Boolean doInBackground(String... urls) {
            final ArrayList<NewsFeed> words = new ArrayList<NewsFeed>();
            words.add(new NewsFeed(R.drawable.image0));
            words.add(new NewsFeed(R.drawable.image1));
            words.add(new NewsFeed(R.drawable.image2));
            words.add(new NewsFeed(R.drawable.image3));
            words.add(new NewsFeed(R.drawable.image4));
            words.add(new NewsFeed(R.drawable.image5));
            words.add(new NewsFeed(R.drawable.image6));
            words.add(new NewsFeed(R.drawable.image7));
            words.add(new NewsFeed(R.drawable.image8));
            words.add(new NewsFeed(R.drawable.image9));
            HttpURLConnection conn = null;
            InputStream inputStream = null;
            try {
                URL url = new URL(NewsList.URL2);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod(getString(R.string.get));
                conn.setDoInput(true);
                // Starts the query
                conn.connect();

                //------------------>>
                HttpGet httppost = new HttpGet(urls[0]);
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse response = httpclient.execute(httppost);

                // StatusLine stat = response.getStatusLine();
                int status = response.getStatusLine().getStatusCode();
                NewsList.errorCode = (int) status;
                if (status == 200) {
                    HttpEntity entity = response.getEntity();
                    String data = EntityUtils.toString(entity);

                    JSONObject jsono = new JSONObject(data);
                    JSONObject json1 = jsono.getJSONObject("responseData");
                    JSONObject json2 = json1.getJSONObject("feed");
                    String feedUrl = json2.getString("feedUrl");
                    JSONArray jarray = json2.getJSONArray("entries");

                    NewsList.content = (int)jarray.length();
                    for (int i = 0; i < jarray.length(); i++) {
                        JSONObject object = jarray.getJSONObject(i);
                        NewsFeed News = new NewsFeed();
                        News.setId(object.getString("link"));
                        News.setIndex(""+i);
                        News.setName(object.getString("title"));
                        News.setAuthor(object.getString("publishedDate"));
                        NewsFeedList.add(News);
                        // Create a list of words

                    }
                    return true;
                } else {
                    return false;
                }

            } catch (ParseException e1) {
                e1.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
                if (inputStream != null) {
                    return true;
                }
                return false;
            }
        }
        protected void onPostExecute(Boolean result) {
            dialog.cancel();
            adapter.notifyDataSetChanged();
            if (NewsList.errorCode == 400 || NewsList.content == 0) {
                TextView brokenText = (TextView) findViewById(R.id.faq_broken);
                brokenText.setVisibility(View.VISIBLE);
                TextView oldText = (TextView) findViewById(R.id.faq_empty);
                oldText.setVisibility(View.INVISIBLE);
                ImageView imgView = (ImageView) findViewById(R.id.broken);
                imgView.setVisibility(View.VISIBLE);
                Toast.makeText(getApplicationContext(), R.string.err1, Toast.LENGTH_LONG).show();
            }
        }
    }

}


