package com.example.julio.bookloot2;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

public class NewsMain extends AppCompatActivity {
    public static String hyperlink;

    /** Tag for the log messages */
    public static final String LOG_TAG = NewsMain.class.getSimpleName();

    /** URL to query the USGS dataset for newsFeed information */
    private static String USGS_REQUEST_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        NewsMain.USGS_REQUEST_URL = (String) getString(R.string.url);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news_search);

        // Kick off an {@link AsyncTask} to perform the network request
        googleNewsAsyncTask task = new googleNewsAsyncTask();
        task.execute();
    }

    /**
     * Update the screen to display information from the given {@link Event}.
     */
    private void updateUi(Event newsFeed) {
        // Display the newsFeed title in the UI
        TextView titleTextView = (TextView) findViewById(R.id.title);
        titleTextView.setText(newsFeed.title);

        // Display the newsFeed date in the UI
        TextView dateTextView = (TextView) findViewById(R.id.publishedDate);
        dateTextView.setText(newsFeed.time);

        //String contentString=newsFeed.googleNewsAlert;
        String contentString = newsFeed.googleNewsAlert;
        contentString = contentString.replaceAll("[&#39;]", "");
        // Display whether or not there was a googleNews alert in the UI
        TextView googleNewsTextView = (TextView) findViewById(R.id.contentSnippet);
        googleNewsTextView.setText(contentString);
    }



    /**
     * {@link AsyncTask} to perform the network request on a background thread, and then
     * update the UI with the first newsFeed in the response.
     */
    private class googleNewsAsyncTask extends AsyncTask<URL, Void, Event> {

        @Override
        protected Event doInBackground(URL... urls) {
            // Create URL object
            URL url = createUrl(NewsMain.USGS_REQUEST_URL);

            // Perform HTTP request to the URL and receive a JSON response back
            String jsonResponse = "";
            try {
                jsonResponse = makeHttpRequest(url);
            } catch (IOException e) {
                // TODO Handle the IOException
            }

            // Extract relevant fields from the JSON response and create an {@link Event} object
            Event newsFeed = extractFeatureFromJson(jsonResponse);

            // Return the {@link Event} object as the result fo the {@link googleNewsAsyncTask}
            return newsFeed;
        }

        /**
         * Update the screen with the given newsFeed (which was the result of the
         * {@link googleNewsAsyncTask}).
         */
        @Override
        protected void onPostExecute(Event newsFeed) {
            if (newsFeed == null) {
                return;
            }

            updateUi(newsFeed);
        }

        /**
         * Returns new URL object from the given string URL.
         */
        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                Log.e(LOG_TAG, "Error with creating URL", exception);
                return null;
            }
            return url;
        }

        /**
         * Make an HTTP request to the given URL and return a String as the response.
         */
        private String makeHttpRequest(URL url) throws IOException {
            String jsonResponse = "";
            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.connect();
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } catch (IOException e) {
                // TODO: Handle the exception
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (inputStream != null) {
                    // function must handle java.io.IOException here
                    inputStream.close();
                }
            }
            return jsonResponse;
        }

        /**
         * Convert the {@link InputStream} into a String which contains the
         * whole JSON response from the server.
         */
        private String readFromStream(InputStream inputStream) throws IOException {
            StringBuilder output = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String line = reader.readLine();
                while (line != null) {
                    output.append(line);
                    line = reader.readLine();
                }
            }
            return output.toString();
        }

        /**
         * Return an {@link Event} object by parsing out information
         * about the first newsFeed from the input newsFeedJSON string.
         */
        private Event extractFeatureFromJson(String newsFeedJSON) {
            try {
                JSONObject jsono = new JSONObject(newsFeedJSON);
                JSONObject json1 = jsono.getJSONObject("responseData");
                JSONObject json2 = json1.getJSONObject("feed");
                String feedUrl = json2.getString("feedUrl");
                JSONArray jarray = json2.getJSONArray("entries");
                // If there are results in the features array
                if (jarray.length() > 0) {
                    // Extract out the first feature (which is an newsFeed)
                    JSONObject firstFeature = jarray.getJSONObject(0);

                    // Extract out the title, time, and googleNews values
                    String title = firstFeature.getString("title");
                    String time = firstFeature.getString("publishedDate");
                    String googleNewsAlert = firstFeature.getString("contentSnippet");
                    String link = firstFeature.getString("link");
                    NewsMain.hyperlink = (String) link;

                    // Create a new {@link Event} object
                    return new Event(title, time, googleNewsAlert);
                }
            } catch (JSONException e) {
                Log.e(LOG_TAG, "Problem parsing the newsFeed JSON results", e);
            }
            return null;
        }
    }
    public void redirect(View view) {
        Toast.makeText(getApplicationContext(), R.string.mss2, Toast.LENGTH_LONG).show();
        Intent redirecti = new Intent(Intent.ACTION_VIEW);
        redirecti.setData(Uri.parse(NewsMain.hyperlink));
        startActivity(redirecti);
        finish();
    }
    public void more(View view) {
        Intent morei = new Intent(this, com.example.julio.bookloot2.NewsList.class);
        startActivity(morei);
        finish();
    }

}
