package com.example.julio.bookloot2;

/**
 * {@Event} represents an newsFeede event. It holds the details
 */
public class Event {

    /** Title of the newsFeede event */
    public final String title;

    /** Time that the newsFeede happened (in milliseconds) */
    public final String time;

    /** Whether or not a googleNews alert was issued (1 if it was issued, 0 if no alert was issued) */
    public final String googleNewsAlert;

    /**
     * Constructs a new {@link Event}.
     *
     */
    public Event(String eventTitle, String eventTime, String eventgoogleNewsAlert) {
        title = eventTitle;
        time = eventTime;
        googleNewsAlert = eventgoogleNewsAlert;
    }
}