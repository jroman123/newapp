package com.example.julio.bookloot2;

import android.widget.ImageView;

public class NewsFeed {

	private String name;
	private String id;
	private String index;
	private String author;


	public NewsFeed() {
		// TODO Auto-generated constructor stub
	}
	public NewsFeed(String index, String name, String id, String author) {
		super();
		this.index = index;

		this.name = name;

		this.id = id;

		this.author = author;



	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}



	//Image
	/** Image resource ID for the word */
	private int mImageResourceId = NO_IMAGE_PROVIDED;

	/** Constant value that represents no image was provided for this word */
	private static final int NO_IMAGE_PROVIDED = -1;


	public NewsFeed(int imageResourceId) {

		mImageResourceId = imageResourceId;

	}


	/**
	 * Return the image resource ID of the word.
	 */
	public int getImageResourceId() {
		return mImageResourceId;
	}

	/**
	 * Returns whether or not there is an image for this word.
	 */
	public boolean hasImage() {
		return mImageResourceId != NO_IMAGE_PROVIDED;
	}
	}
